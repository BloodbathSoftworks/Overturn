Vector		CalcLocus_Position	( CBaseEntity *pEntity, CBaseEntity *pLocus, const char *szText );
Vector		CalcLocus_Velocity	( CBaseEntity *pEntity, CBaseEntity *pLocus, const char *szText );
float		CalcLocus_Ratio		( CBaseEntity *pLocus, const char *szText );