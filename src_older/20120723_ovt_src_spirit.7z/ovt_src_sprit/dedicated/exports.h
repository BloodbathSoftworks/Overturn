//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================

// functions exported from front end to engine
#ifndef INC_EXPORTSH
#define INC_EXPORTSH

extern void ErrorMessage(int nLevel, const char *pszErrorMessage);

#endif // !INC_EXPORTSH