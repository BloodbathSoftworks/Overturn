Spirit of Half-Life version 1.2
Source code release 20/11/03

Overturn 11:03 PM, May 14, 2012.